#!/bin/bash

PREITEMS="account,eureka,keeper";
POSTITEMS="front,proxy,yard,gateway";
WAITTIME=4;

function usage {
  echo "Usage : ./control.sh [start|stop|restart|setimage] [front|account|eureka|gateway|keeper|proxy|yard|notihub|all]";
  echo;
}

function usage_setimage {
  echo "Usage : ./control.sh setimage [front|account|eureka|gateway|keeper|proxy|yard|notihub|all] [new-image]";
  echo;
}

function restart {
  if [ -z "$1" ]; then
    usage;
  else
    case $1 in
      front|account|eureka|gateway|keeper|proxy|yard|notihub )
        restart_ms $1;
        ;;
      all )
        for item in `echo $PREITEMS |tr "," "\n"`
        do
          restart_ms $item;
        done;

        sleep $WAITTIME;

        for item in `echo $POSTITEMS |tr "," "\n"`
        do
          restart_ms $item;
        done;
        ;;
      * )
        echo "'$1' is wrong" ;
        usage;
        ;;
    esac
  fi;
}

function stop {
  if [ -z "$1" ]; then
    usage;
  else
    case $1 in
      front|account|eureka|gateway|keeper|proxy|yard|notihub )
        stop_ms $1;
        ;;
      all )
        for item in `echo $PREITEMS |tr "," "\n"`
        do
          stop_ms $item;
        done;

        for item in `echo $POSTITEMS |tr "," "\n"`
        do
          stop_ms $item;
        done;
        ;;
      * )
        echo "'$1' is wrong" ;
        usage;
        ;;
    esac
  fi;
}

function setimage {
  if [ -z "$1" ]; then
    usage_setimage;
  elif [ -z "$2" ]; then
    usage_setimage;
  else
    case $1 in
      front|account|eureka|gateway|keeper|proxy|yard|notihub )
        setimage_ms $1 $2;
        ;;
      all )
        for item in `echo $PREITEMS |tr "," "\n"`
        do
          setimage_ms $item $2;
        done;

        for item in `echo $POSTITEMS |tr "," "\n"`
        do
          setimage_ms $item $2;
        done;
        ;;
      * )
        echo "'$1' is wrong" ;
        usage_setimage;
        ;;
    esac
  fi;
}

function stop_ms {
  kubectl scale deployment $1 --replicas 0
}

function restart_ms {
  kubectl scale deployment $1 --replicas 0
  sleep $WAITTIME;
  kubectl scale deployment $1 --replicas 1
}

function setimage_ms {
  kubectl set image deploy $1 $1=$2
}

########## Start ##########
if [ -z "$1" ]; then
  usage;
else
  case $1 in
    start|restart)
      restart $2;
      ;;
    stop)
      stop $2;
      ;;
    setimage)
      setimage $2 $3;
      ;;
    *)
      echo "'$1' is wrong" ;
      usage;
      ;;
  esac
fi;
##########  End  ##########
